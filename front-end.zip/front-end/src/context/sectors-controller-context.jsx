import * as React from 'react';

import { SectorsControllerProvider } from './sectors-controller';

export const SectorsControllerContext = ({ children }) => (
  <SectorsControllerProvider>{children}</SectorsControllerProvider>
);
