import * as React from 'react';

import { useSectors } from '../adapters/sectors/sectors';
import { normalizeResponse } from '../utils/helpers-fn';
import { useSignups } from '../adapters/sectors/signups';

const SectorsContext = React.createContext({});
SectorsContext.displayName = 'SectorsContext';

const SectorsControllerProvider = ({ children }) => {
  const newOrderListState = normalizeResponse(useSectors());

  console.log(useSectors());

  const signUpState = normalizeResponse(useSignups());

  const handleSignUp = async (formValues) => {
    await signUpState.mutateAsync(formValues);
  };

  return (
    <SectorsContext.Provider
      value={{
        newOrderListState,
        handleSignUp
      }}
    >
      {children}
    </SectorsContext.Provider>
  );
};

const useSectorsContext = () => {
  const context = React.useContext(SectorsContext);

  if (context === undefined) {
    throw new Error('It can be used only with a SectorsControllerProvider');
  }

  return context;
};

export { SectorsControllerProvider, useSectorsContext };
