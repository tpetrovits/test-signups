import * as React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { LoginForm } from './shared-components/login-form';
import { SectorsControllerContext } from './context/sectors-controller-context';

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <SectorsControllerContext>
      <LoginForm />
    </SectorsControllerContext>
  </QueryClientProvider>
);

export default App;
