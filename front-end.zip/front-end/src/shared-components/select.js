import * as React from 'react';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem';

export const SelectElement = ({ options, ...rest }) => (
  <FormControl fullWidth>
    <InputLabel htmlFor='grouped-select'>Sectors</InputLabel>
    <Select id='grouped-select' label='Grouping' multiple {...rest}>
      {options?.map((d) => (
        <MenuItem value={d.id} key={d.id}>
          {d.name}
        </MenuItem>
      ))}
    </Select>
  </FormControl>
);
