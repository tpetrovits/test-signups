import * as React from 'react';
import Alert from '@mui/material/Alert';
import AlertTitle from '@mui/material/AlertTitle';
import Collapse from '@mui/material/Collapse';

export const ErrorAlert = ({ toggleAlertBox, closeToggleAlertBox, error }) => (
  <Collapse in={toggleAlertBox}>
    <Alert severity='error' sx={{ mb: '25px' }} onClose={() => closeToggleAlertBox()}>
      <AlertTitle>{error?.code}</AlertTitle>
      {error?.description}
    </Alert>
  </Collapse>
);
