import * as yup from 'yup';

export const formValidator = yup.object().shape({
  name: yup.string().required('This field is required').min(3, 'Min length is 3'),
  terms: yup.bool().oneOf([true], 'You must accept the terms and conditions')
});
