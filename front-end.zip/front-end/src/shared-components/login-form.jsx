import * as React from 'react';
import { yupResolver } from '@hookform/resolvers/yup';
import ArrowForwardOutlinedIcon from '@mui/icons-material/ArrowForwardOutlined';
import Button from '@mui/material/Button';
import { Checkbox, FormControlLabel } from '@mui/material';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import { Controller, useForm } from 'react-hook-form';
import { useSectorsContext } from '../context/sectors-controller';
import { hasError, hasErrorMessage } from '../utils/helpers-fn';
import { ErrorAlert } from './error-alert/error-alert';
import { formValidator } from './login-form-validator';
import { Form, FormInputWrapper } from './styles';
import { SelectElement } from './select';

export const LoginForm = () => {
  const { newOrderListState, handleSignUp } = useSectorsContext();

  const { result: options, error, isLoading } = newOrderListState;

  const {
    handleSubmit,
    watch,
    control,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(formValidator),
    defaultValues: {
      select: []
    }
  });

  const watchFields = watch();

  const [toggleAlertBox, setToggleAlertBox] = React.useState(false);

  const closeToggleAlertBox = () => {
    setToggleAlertBox(false);
  };

  const onSubmit = (params) => {
    handleSignUp(params);
  };

  React.useEffect(() => {
    if (error && error.code !== 404) {
      setToggleAlertBox(true);
    }
  }, [error]);

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      {isLoading && <Typography>Loading...</Typography>}
      {error && <ErrorAlert error={error} />}
      <Typography variant='h3'>Form submit</Typography>
      <FormInputWrapper>
        <Controller
          render={({ field }) => (
            <TextField
              autoFocus
              id='name'
              type='text'
              label='Name'
              disabled={isLoading}
              sx={{
                width: '100%',
                mb: '25px',
                mt: '25px'
              }}
              error={hasError(errors, 'name')}
              helperText={hasErrorMessage(errors, 'name')}
              size='small'
              {...field}
            />
          )}
          name='name'
          control={control}
          defaultValue=''
        />

        <Controller
          name='select'
          control={control}
          render={({ field }) => <SelectElement options={options} {...field} />}
        />

        <Controller
          name='terms'
          control={control}
          render={({ field }) => <FormControlLabel control={<Checkbox {...field} />} label='Agree to terms!' />}
        />

        {error?.code ? (
          <ErrorAlert error={error} toggleAlertBox={toggleAlertBox} closeToggleAlertBox={closeToggleAlertBox} />
        ) : null}

        <div>
          <Button
            type='submit'
            disabled={isLoading || !watchFields?.name || !watchFields?.terms}
            variant='contained'
            color='primary'
            endIcon={<ArrowForwardOutlinedIcon />}
          >
            Submit
          </Button>
        </div>
      </FormInputWrapper>
    </Form>
  );
};
