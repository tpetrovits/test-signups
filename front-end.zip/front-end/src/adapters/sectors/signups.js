import { useMutation } from '@tanstack/react-query';

import { postData } from '../api';

export const useSignups = () => useMutation((newData) => postData(`/api/signups`, newData));
