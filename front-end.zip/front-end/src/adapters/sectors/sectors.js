import { useQuery } from '@tanstack/react-query';

import { getData } from '../api';

export const useSectors = () =>
  useQuery({
    queryKey: ['/api/sectors'],
    queryFn: () => getData('/api/sectors'),
    options: {
      keepPreviousData: true
    }
  });
